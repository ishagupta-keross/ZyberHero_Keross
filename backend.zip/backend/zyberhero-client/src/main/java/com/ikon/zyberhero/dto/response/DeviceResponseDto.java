package com.ikon.zyberhero.dto.response;

import lombok.Data;

@Data
public class DeviceResponseDto {
    private Long deviceId;
    private String deviceUuid;
    private Integer childId;
}